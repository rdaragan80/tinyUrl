package com.shortener.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shortener.model.requests.HttpTinyUrlRequest;
import com.shortener.model.Error;
import com.shortener.model.ErrorStatus;
import com.shortener.model.RestOriginalUrlResponse;
import com.shortener.model.RestTinyUrlResponse;
import com.shortener.model.requests.RestTinyUrlRequest;
import com.shortener.model.responses.ErrorResponse;
import com.shortener.persistence.dao.ILocalStorageIntf;
import com.shortener.service.UrlService;
import com.shortener.util.CommonUtils;
import com.shortener.validation.Validator;


@Controller
public class UrlController {
    @Autowired
    private ILocalStorageIntf urlStoreService;
    
    @Autowired
    private Validator validator;
    
    @Autowired
	private CommonUtils commonUtils;
    
    @Autowired
    UrlService urlservice;

    @RequestMapping(value="/", method=RequestMethod.GET)
    public String showForm(HttpTinyUrlRequest request) {
        return "shortener";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public void redirectToUrl(@PathVariable String id, HttpServletResponse resp) throws Exception {
        final String url = urlStoreService.findUrlById(id);
        if (url != null) {
            resp.addHeader("Location", url);
            resp.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
        } else {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @RequestMapping(value="/", method = RequestMethod.POST)
    public ModelAndView shortenUrl(HttpServletRequest httpRequest,
                                   HttpTinyUrlRequest request,
                                   BindingResult bindingResult) {
        String url = request.getUrl();
        Long expiredTime = request.getExpireTime();
        ErrorResponse errorResponse = validator.validateUrl(url); 
        processValidationResponse(bindingResult, url, errorResponse);

        ModelAndView modelAndView = new ModelAndView("shortener");
        if (!bindingResult.hasErrors()) {
        	final String id = commonUtils.generateIdFromUrl(url);
            urlStoreService.storeUrl(id, url,expiredTime);
            String prefix = commonUtils.buildTinyUrl(httpRequest);
            modelAndView.addObject("shortenedUrl", prefix + "/" + id);
        }
        return modelAndView;
    }
    
    @SuppressWarnings("rawtypes")
	@RequestMapping(
			method = RequestMethod.POST,
			value = "/createTinyUrl",
			consumes = "application/json",
			produces = "application/json")
    public ResponseEntity generateTinyUrl(@RequestBody RestTinyUrlRequest request) {
    	String url = request.getUrl();	
    	Long expiredTime = request.getExpireTime();
    	ErrorResponse errorResponse = validator.validateUrl(url);
		if(errorResponse!=null){
			return  new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
		}

    	RestTinyUrlResponse response = urlservice.generateTinyUrl(url,expiredTime);
    	return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @SuppressWarnings("rawtypes")
  	@RequestMapping(method = RequestMethod.GET, value = "/getOriginalUrl/{id}", produces = "application/json")
      public ResponseEntity getOriginalUrl(@PathVariable String id, HttpServletRequest request) throws Exception {
      	ErrorResponse errorResponse = validator.validateId(id);
  		if(errorResponse!=null){
  			return  new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
  		}
          
  		RestOriginalUrlResponse origUrlresponse = urlservice.getOriginalUrl(id);
  		return new ResponseEntity<>(origUrlresponse, HttpStatus.FOUND);
      }
    
	private void processValidationResponse(BindingResult bindingResult,String url, ErrorResponse errorResponse) {
		if(errorResponse != null){
	        List<ErrorStatus> list = errorResponse.getStatus();        
	        for(ErrorStatus errorStatus : list){
	        	List<Error> errList = errorStatus.getErrors();
	        	for(Error currentError : errList){
	        		bindingResult.addError(new ObjectError(currentError.getField(), currentError.getReason() + ": for input: " + url));
	        	}
	        }
        }
	}
}
