package com.shortener.validation;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.shortener.model.Error;
import com.shortener.model.responses.ErrorResponse;
import com.shortener.persistence.dao.ILocalStorageIntf;
import com.shortener.util.CommonUtils;
import com.shortener.util.StaticDataUtil;


@Component
public class Validator {
	
	@Autowired
	private CommonUtils commonUtils;
	
	@Autowired
	private StaticDataUtil staticDataUtil;
	
	@Autowired
    private ILocalStorageIntf urlStoreService;

	public ErrorResponse validateUrl(String url) {
		List<Error> errors = new ArrayList<Error>();
		
		if(StringUtils.isEmpty(url)){
			errors = commonUtils.setError(errors, "url", StaticDataUtil.STATUS.MANDATORY_FIELD_CHECK, "Url parameter should not be empty");
		}
		else{
			try {
	            new URL(url);
	        } catch (MalformedURLException e) {
	        	errors = commonUtils.setError(errors, "url", StaticDataUtil.STATUS.URL_PARAMETER_IS_NOT_VALID, "Url is not valid");
	        }
		}
        		
		if(errors.isEmpty()){
			return null;
		}
		return commonUtils.generateErrorResponse("failed_validation",errors);
	}

	public ErrorResponse validateId(String id) {
		List<Error> errors = new ArrayList<Error>();
		if(urlStoreService.findUrlById(id) == null){
			errors = commonUtils.setError(errors, "url", StaticDataUtil.STATUS.ORIGINAL_URL_NOT_FOUND, "Unable to find original url based on id provided.");
		}
		if(errors.isEmpty()){
			return null;
		}
		return commonUtils.generateErrorResponse("failed_validation",errors);
	}
}
