package com.shortener.persistence.dao;


public interface ILocalStorageIntf {
    String findUrlById(String id);

    void storeUrl(String id, String url, Long expireAfterAccess);
}
