package com.shortener.util;

import org.springframework.stereotype.Component;

@Component
public class StaticDataUtil {
	
	public static interface STATUS {
		public static  int PPOCESS_SUCCESS = 0;
		public static int  PROCESS_FAILED_400 = 400;//Bad Request
		public static int  PROCESS_FAILED_404 = 404;//Not Found
		public static int  PROCESS_FAILED_422 = 422;//Unprocessable Entity
		public static int PROCESS_SUCCESS_CREATED = 201;
		public static String MAXIMUM_LENGTH_FAILED = "MAXIMUM_LENGTH_FAILED";
		public static String MANDATORY_FIELD_CHECK = "MANDATORY_FIELD_CHECK";
		public static String URL_PARAMETER_IS_NOT_VALID = "URL_PARAMETER_IS_NOT_VALID"; 
		public static String ORIGINAL_URL_NOT_FOUND = "ORIGINAL_URL_NOT_FOUND";
	}

}
