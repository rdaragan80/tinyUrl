package com.shortener.util;

import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.google.common.hash.Hashing;
import com.shortener.model.Error;
import com.shortener.model.ErrorStatus;
import com.shortener.model.responses.ErrorResponse;

import org.springframework.stereotype.Component;

@Component
public class CommonUtils {
	
	public List<Error> setError(List<Error> errors , String field , String key, String reason )
	{
		Error error = new Error();
		error.setField(field);
		error.setKey(key);
		error.setReason(reason);
		errors.add(error);
		return errors;
	}
	
	
	public ErrorResponse generateErrorResponse(String name, List<Error> errors) {
		ErrorResponse response = new ErrorResponse();
		List<ErrorStatus> errorStatusList = new ArrayList<ErrorStatus>();
		ErrorStatus errorStatus = new ErrorStatus();
		errorStatus.setName(name);
		errorStatus.setErrors(errors);
		errorStatusList.add(errorStatus);
		response.setStatus(errorStatusList);
		return response;

	}
	
	public String generateIdFromUrl(String url){
	        SecureRandom random = null;
			try {
				random = SecureRandom.getInstanceStrong();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
	        int seed = random.nextInt(10000);

	        final String id = Hashing.murmur3_32(seed).hashString(url, StandardCharsets.UTF_8).toString();
	        return id;
	}
	
	public String buildTinyUrl(HttpServletRequest httpRequest) {
		String requestUrl = httpRequest.getRequestURL().toString();
		String prefix = requestUrl.substring(0, requestUrl.indexOf(httpRequest.getRequestURI(),
		    "http://".length()));
		return prefix;
	}

}
