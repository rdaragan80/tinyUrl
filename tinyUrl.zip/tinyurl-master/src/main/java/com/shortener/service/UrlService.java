package com.shortener.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shortener.model.RestOriginalUrlResponse;
import com.shortener.model.RestTinyUrlResponse;
import com.shortener.persistence.dao.ILocalStorageIntf;
import com.shortener.util.CommonUtils;



@Service
public class UrlService {
	
	private static final String shortUrl = "http://mydomain.com/";
	 @Autowired
	 private ILocalStorageIntf urlStoreService;

	@Autowired
	private CommonUtils commonUtils;
	
	public RestTinyUrlResponse generateTinyUrl(String url,Long expireAfterAccess) {
		String id = commonUtils.generateIdFromUrl(url);
		urlStoreService.storeUrl(id, url,expireAfterAccess); 
    	RestTinyUrlResponse tiny = new RestTinyUrlResponse();
    	tiny.setTinyurl(shortUrl + id);	    	
    	return tiny;
	}
	
	public RestOriginalUrlResponse getOriginalUrl(String id){
		 final String url = urlStoreService.findUrlById(id);
	        if (url != null) {
	        	RestOriginalUrlResponse orig = new RestOriginalUrlResponse();
	        	orig.setOriginalUrl(url);
	        	return orig;
	        } 
		return null;
	}
}
