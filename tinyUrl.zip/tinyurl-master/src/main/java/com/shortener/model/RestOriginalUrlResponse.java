package com.shortener.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RestOriginalUrlResponse {
	
	@JsonProperty("originalUrl")
	private String originalUrl;

	@JsonProperty("originalUrl")
	public String getOriginalUrl() {
		return originalUrl;
	}

	@JsonProperty("originalUrl")
	public void setOriginalUrl(String originalUrl) {
		this.originalUrl = originalUrl;
	}

}
