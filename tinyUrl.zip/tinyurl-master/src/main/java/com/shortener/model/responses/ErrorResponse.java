package com.shortener.model.responses;

import com.shortener.model.ErrorStatus;
import com.shortener.model.responses.Response;

import java.util.List;

public class ErrorResponse implements Response{

	private List<ErrorStatus> status;

	public List<ErrorStatus> getStatus () {
		return status;
	}

	public void setStatus(List<ErrorStatus> status) {
		this.status = status;
	}
	
	
}