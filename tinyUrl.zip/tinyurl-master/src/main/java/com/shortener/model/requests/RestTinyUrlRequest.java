package com.shortener.model.requests;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)

public class RestTinyUrlRequest {
	
	@JsonProperty("expireTime")
	private Long expireTime;
	
	@JsonProperty("url")
	private String url;

	@JsonProperty("url")
	public String getUrl() {
		return url;
	}

	@JsonProperty("url")
	public void setUrl(String url) {
		this.url = url;
	}

	@JsonProperty("expireTime")
	public Long getExpireTime() {
		return expireTime;
	}

	@JsonProperty("expireTime")
	public void setExpireTime(Long expireTime) {
		this.expireTime = expireTime;
	}



}
