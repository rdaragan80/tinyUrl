package com.shortener.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RestTinyUrlResponse {
	
	@JsonProperty("tinyurl")
	private String tinyurl;

	@JsonProperty("tinyurl")
	public String getTinyurl() {
		return tinyurl;
	}

	@JsonProperty("tinyurl")
	public void setTinyurl(String tinyurl) {
		this.tinyurl = tinyurl;
	}

}
