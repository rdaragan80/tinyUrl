package com.shortener.model.responses;

public interface Response {

}
